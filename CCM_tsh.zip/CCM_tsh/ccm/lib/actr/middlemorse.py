#MiddleMorse
from pymorse import Morse


morserobot = Morse()


    



